// Note:  Please do not change the prewritten code

// import the required module here

const Solution = () => {
    const nums = [1, 2, 3, 4, 5];
    // write your code here to Display the results of the calculations on the console.

};
Solution();
module.exports = Solution;
