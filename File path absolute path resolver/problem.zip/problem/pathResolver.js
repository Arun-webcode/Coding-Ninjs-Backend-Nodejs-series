exports.getAbsolutePath = (filePath) => {
  // Write your code here
};
