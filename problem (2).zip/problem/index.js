import events from "events";

class FitnessTracker extends events.EventEmitter {
  constructor() {
    super();
    this.progress = 0;
    this.goal = 1000;
  }

  addExercise(exercise) {
    // Update the progress based on calories burned from the exercise
    this.progress += exercise.caloriesBurned;

    // Check if the goal is reached
    if (this.progress >= this.goal) {
      // Emit a 'goalReached' event
      this.emit("goalReached");

      // Reset progress for the next goal
      this.progress = 0;
    }
  }
}

const Solution = () => {
  // Create an instance of FitnessTracker
  const tracker = new FitnessTracker();

  // Define a listener that sends a congratulatory message to the user upon reaching their fitness goal
  const congratulatoryMessageListener = () => {
    console.log("Congratulations! You have reached your fitness goal");
  };

  // Attach the listener to the 'goalReached' event
  tracker.on("goalReached", congratulatoryMessageListener);

  // Simulate adding exercise
  tracker.addExercise({ name: "Running", caloriesBurned: 500 });
  tracker.addExercise({ name: "Weightlifting", caloriesBurned: 600 });
};

Solution();

export { FitnessTracker, Solution };
