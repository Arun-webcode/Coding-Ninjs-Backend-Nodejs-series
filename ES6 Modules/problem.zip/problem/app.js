// app.js - our main application file
const math = require("./math.js");

const nums = [1, 2, 3, 4, 5];
console.log(`The sum is ${maths.sum(nums)}`);
console.log(`The mean is ${maths.mean(nums)}`);


