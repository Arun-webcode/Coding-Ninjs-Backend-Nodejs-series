// Import required module

const Solution = () => {
  // Write your code here
};

Solution();
module.exports = Solution;
