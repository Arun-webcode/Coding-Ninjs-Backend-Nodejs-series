// Please don't change the pre-written code

const express = require("express");
const server = express();

// Write your code here

module.exports = server;
